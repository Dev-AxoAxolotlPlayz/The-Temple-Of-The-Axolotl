package com.devaxo.templeoftheaxolotl.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.NeutralMob;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.TorchBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public class AbyssalTorchBlock extends TorchBlock {
    public AbyssalTorchBlock(Properties properties) { super(ParticleTypes.SOUL_FIRE_FLAME, properties); }
    @Override public void onPlace(BlockState state, Level level, BlockPos pos, BlockState previous, boolean moving) {
        super.onPlace(state, level, pos, previous, moving);
        if (!level.isClientSide) level.scheduleTick(pos, this, 1);
    }
    @Override public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        Vec3 center = Vec3.atCenterOf(pos);
        for (Mob mob : level.getEntitiesOfClass(Mob.class, new AABB(pos).inflate(5.0),
                m -> m.isAlive() && (m instanceof Enemy || (m instanceof NeutralMob neutral && neutral.isAngry())))) {
            Vec3 away = mob.position().subtract(center);
            double distance = away.length();
            if (distance < 0.01 || distance > 5.0) continue;
            Vec3 horizontal = new Vec3(away.x, 0, away.z);
            if (horizontal.lengthSqr() < 0.0001) continue;
            Vec3 impulse = horizontal.normalize().scale(0.22 * (1.0 - distance / 6.0));
            mob.setDeltaMovement(mob.getDeltaMovement().add(impulse));
            mob.hurtMarked = true;
        }
        level.scheduleTick(pos, this, 2);
    }
}
